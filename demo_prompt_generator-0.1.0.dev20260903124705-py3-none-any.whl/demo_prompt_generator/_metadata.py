from pathlib import Path

app_name = "demo-prompt-generator"
app_entrypoint = "demo_prompt_generator.backend.app:app"
app_slug = "demo_prompt_generator"
api_prefix = "/api"
dist_dir = Path(__file__).parent / "__dist__"
