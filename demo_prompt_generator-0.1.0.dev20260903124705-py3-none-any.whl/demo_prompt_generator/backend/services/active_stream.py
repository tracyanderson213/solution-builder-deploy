"""Active stream management for Claude Code agent execution.

Provides in-memory event buffering with cursor-based retrieval.
Follows Databricks Agent Skills (DAS) patterns for reliable streaming.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Callable, ClassVar

from ..core._config import logger


@dataclass
class StreamEvent:
    """A single event in the stream with timestamp cursor."""
    timestamp: float  # Unix timestamp, used as cursor
    data: dict[str, Any]


@dataclass
class ActiveStream:
    """
    In-memory buffer for a single agent execution's events.

    Supports cursor-based retrieval for SSE reconnection.
    Thread-safe event accumulation via append-only list.
    """
    execution_id: str
    project_id: str
    events: list[StreamEvent] = field(default_factory=list)
    is_complete: bool = False
    is_cancelled: bool = False
    is_error: bool = False
    error_message: str | None = None
    task: asyncio.Task | None = None
    session_id: str | None = None  # Stored after completion for resumption
    # When the watcher sees README.md change it sets this flag and the SSE
    # loop will keep the stream open (past the agent's mark_complete) until
    # the narrative regen lands. Cleared once `narrative_updated` is added.
    narrative_pending: bool = False

    def add_event(self, event_data: dict[str, Any]) -> None:
        """Append an event with automatic timestamp cursor.

        Args:
            event_data: Dict with 'type' key and event-specific data.
        """
        self.events.append(StreamEvent(
            timestamp=time.time(),
            data=event_data,
        ))

    def get_events_since(self, cursor: float = 0.0) -> tuple[list[dict], float]:
        """
        Return events after the given cursor and the new cursor position.

        Args:
            cursor: Timestamp cursor from previous call (0.0 for start)

        Returns:
            Tuple of (list of event dicts with _cursor, new cursor position)
        """
        new_events = [
            {**e.data, "_cursor": e.timestamp}
            for e in self.events
            if e.timestamp > cursor
        ]
        new_cursor = self.events[-1].timestamp if self.events else cursor
        return new_events, new_cursor

    def mark_complete(self, session_id: str | None = None) -> None:
        """Mark stream as complete, optionally storing session_id."""
        self.is_complete = True
        self.session_id = session_id

    def mark_error(self, error_message: str) -> None:
        """Mark stream as errored. Idempotent: a single failure can reach this
        via up to three paths (the generator's except, run_agent's except, and
        start_stream's wrapper) — without this guard each appends another
        `{"type":"error"}` event, so the UI renders 2–3 duplicate red bubbles."""
        if self.is_error:
            return
        self.is_error = True
        self.error_message = error_message
        self.add_event({"type": "error", "error": error_message})

    def mark_cancelled(self) -> None:
        """Mark stream as cancelled."""
        self.is_cancelled = True
        self.add_event({"type": "cancelled"})


class ActiveStreamManager:
    """
    Singleton manager for all active streams.

    Provides stream lifecycle management and cleanup.
    Uses per-project locks to prevent concurrent agent invocations.
    """
    _instance: ClassVar["ActiveStreamManager | None"] = None
    _streams: dict[str, ActiveStream]
    _cleanup_interval: float = 300  # 5 minutes
    _stream_ttl: float = 600  # 10 minutes after completion

    def __init__(self):
        self._streams = {}
        self._project_locks: dict[str, asyncio.Lock] = {}
        self._last_cleanup = time.time()

    def get_project_lock(self, project_id: str) -> asyncio.Lock:
        """Get or create a per-project lock for serializing agent invocations."""
        if project_id not in self._project_locks:
            self._project_locks[project_id] = asyncio.Lock()
        return self._project_locks[project_id]

    @classmethod
    def get_instance(cls) -> "ActiveStreamManager":
        """Get or create the singleton instance."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def create_stream(self, execution_id: str, project_id: str) -> ActiveStream:
        """Create and register a new stream."""
        stream = ActiveStream(execution_id=execution_id, project_id=project_id)
        self._streams[execution_id] = stream
        self._maybe_cleanup()
        logger.debug(f"Created stream for execution {execution_id}")
        return stream

    def get_stream(self, execution_id: str) -> ActiveStream | None:
        """Get a stream by execution ID."""
        return self._streams.get(execution_id)

    def get_project_stream(self, project_id: str) -> ActiveStream | None:
        """Get the active (running) stream for a project, if any."""
        for stream in self._streams.values():
            if (
                stream.project_id == project_id
                and not stream.is_complete
                and not stream.is_cancelled
                and not stream.is_error
            ):
                return stream
        return None

    def get_project_stream_any(self, project_id: str) -> ActiveStream | None:
        """Get the most recent stream for a project regardless of completion.

        Used by background tasks (narrative regen) that may finish after the
        agent has flipped `is_complete`. The SSE loop's narrative_pending
        flag keeps the connection open in that window so late-arriving events
        still reach the UI.
        """
        candidates = [s for s in self._streams.values() if s.project_id == project_id]
        if not candidates:
            return None
        # Most recent by event order — streams without events fall back to
        # the order they were inserted into the dict.
        candidates.sort(
            key=lambda s: s.events[-1].timestamp if s.events else 0.0,
            reverse=True,
        )
        return candidates[0]

    async def start_stream(
        self,
        stream: ActiveStream,
        agent_coroutine: Callable[[], Any]
    ) -> None:
        """Start agent execution as a background task."""
        async def run_agent():
            try:
                await agent_coroutine()
            except asyncio.CancelledError:
                stream.mark_cancelled()
                logger.info(f"Stream {stream.execution_id} cancelled")
            except Exception as e:
                stream.mark_error(str(e))
                logger.error(f"Stream {stream.execution_id} error: {e}")

        stream.task = asyncio.create_task(run_agent())
        logger.debug(f"Started stream task for {stream.execution_id}")

    def remove_stream(self, execution_id: str) -> None:
        """Remove a stream from the manager."""
        if execution_id in self._streams:
            del self._streams[execution_id]
            logger.debug(f"Removed stream {execution_id}")

    def _maybe_cleanup(self) -> None:
        """Best-effort cleanup on the hot path (create_stream). Bounded by a
        5-min guard so it rarely does work; the AUTHORITATIVE bound is
        `sweep_expired`, driven by the reaper loop (a quiet instance never calls
        create_stream, so relying on this alone leaked terminal streams forever)."""
        now = time.time()
        if now - self._last_cleanup < self._cleanup_interval:
            return
        self._last_cleanup = now
        self.sweep_expired()

    def sweep_expired(self) -> int:
        """Drop terminal (complete/error/cancelled) streams past TTL. Called from
        the reaper loop on a fixed cadence — NOT gated on create_stream — so
        `_streams` is bounded even on an idle instance. Each ActiveStream holds
        its full event list (can be MBs), so an unbounded `_streams` was a real
        memory leak. A terminal stream with NO events is dropped immediately
        (it's done and carries nothing). Returns the number removed."""
        now = time.time()
        to_remove = []
        for execution_id, stream in list(self._streams.items()):
            if not (stream.is_complete or stream.is_error or stream.is_cancelled):
                continue
            if not stream.events:
                to_remove.append(execution_id)  # terminal + empty → safe to drop
            elif now - stream.events[-1].timestamp > self._stream_ttl:
                to_remove.append(execution_id)
        for execution_id in to_remove:
            self.remove_stream(execution_id)
        if to_remove:
            logger.info(f"[streams] swept {len(to_remove)} terminal stream(s)")
        return len(to_remove)

    def forget(self, project_id: str) -> None:
        """Drop a project's per-project lock (called when a project is deleted).
        Any terminal streams for it are reclaimed by sweep_expired on cadence."""
        self._project_locks.pop(project_id, None)

    def cancel_all(self) -> int:
        """Mark every active stream as cancelled. Used at app shutdown
        so the SSE generator loops in routes/agent.py exit on their next
        poll iteration instead of blocking the lifespan teardown for the
        full SSE_WINDOW_SECONDS (~50 s). The associated agent task is
        also cancelled if still running.

        Returns the number of streams cancelled.
        """
        cancelled = 0
        for execution_id, stream in list(self._streams.items()):
            if stream.is_complete or stream.is_error or stream.is_cancelled:
                continue
            stream.mark_cancelled()
            task = getattr(stream, "task", None)
            if task is not None and not task.done():
                task.cancel()
            cancelled += 1
        return cancelled


# Convenience function to get the manager
def get_stream_manager() -> ActiveStreamManager:
    """Get the singleton stream manager instance."""
    return ActiveStreamManager.get_instance()
