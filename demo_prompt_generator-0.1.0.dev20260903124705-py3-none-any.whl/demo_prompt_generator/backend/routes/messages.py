"""Project messages CRUD endpoints."""

from __future__ import annotations

from fastapi import HTTPException
from sqlmodel import select

from ..core import Dependencies, create_router
from ..models import (
    Message,
    MessageCreateRequest,
    MessageOut,
    decompress_reasoning,
)
from ..services.agent import get_client_pool
from .projects import _get_authorized_project, _require_write_access

router = create_router()


def _get_user_email(headers) -> str:
    """Extract user email from Databricks Apps headers."""
    if headers and headers.user_email:
        return headers.user_email
    if headers and headers.user_id:
        return headers.user_id
    return "anonymous@local"


@router.get(
    "/projects/{project_id}/messages",
    response_model=list[MessageOut],
    operation_id="listProjectMessages",
)
def list_project_messages(
    project_id: str,
    session: Dependencies.Session,
    headers: Dependencies.Headers,
    config: Dependencies.Config,
    limit: int = 50,
):
    """List recent messages for a project, oldest first (limited to last N messages).

    Excludes `reasoning_data` from the response — it can be hundreds of KB per
    assistant message and is only needed when the user expands the "Reasoning"
    toggle. Clients should fetch it lazily via `GET /messages/{id}/reasoning`.
    `has_reasoning: bool` tells the UI whether the toggle should appear.
    """
    user_email = _get_user_email(headers)
    _get_authorized_project(
        session, project_id, user_email, config.template_admin_emails
    )

    # Project specific columns — skipping `reasoning_data` means PG doesn't
    # stream potentially-MBs of compressed blobs to the app. We compute
    # has_reasoning as a boolean from the column's NULL-ness.
    stmt = (
        select(
            Message.id,
            Message.project_id,
            Message.role,
            Message.content,
            Message.context_hint,
            Message.is_error,
            Message.is_cancelled,
            (Message.reasoning_data.isnot(None)).label("has_reasoning"),  # type: ignore[attr-defined]
            Message.created_at,
        )
        .where(Message.project_id == project_id)
        .order_by(Message.created_at.desc())
        .limit(limit)
    )
    rows = list(reversed(session.exec(stmt).all()))

    return [
        MessageOut(
            id=row.id,
            project_id=row.project_id,
            role=row.role,
            content=row.content,
            context_hint=row.context_hint,
            is_error=row.is_error,
            is_cancelled=row.is_cancelled,
            has_reasoning=bool(row.has_reasoning),
            reasoning_data=None,  # Fetched lazily via /messages/{id}/reasoning.
            created_at=row.created_at,
        )
        for row in rows
    ]


@router.get(
    "/messages/{message_id}/reasoning",
    operation_id="getMessageReasoning",
)
def get_message_reasoning(
    message_id: int,
    session: Dependencies.Session,
    headers: Dependencies.Headers,
    config: Dependencies.Config,
):
    """Fetch and decompress reasoning for a single message.

    Called on demand when the user expands the "Reasoning" toggle. Verified via
    the owning project's user_email (or admin).
    """
    user_email = _get_user_email(headers)

    # One projected query that also joins the project to check ownership.
    row = session.exec(
        select(Message.project_id, Message.reasoning_data).where(Message.id == message_id)
    ).first()
    if row is None:
        raise HTTPException(status_code=404, detail="Message not found")

    project_id, reasoning_bytes = row
    _get_authorized_project(
        session, project_id, user_email, config.template_admin_emails
    )

    return {"reasoning_data": decompress_reasoning(reasoning_bytes)}


@router.post(
    "/projects/{project_id}/messages",
    response_model=MessageOut,
    operation_id="addProjectMessage",
)
def add_project_message(
    project_id: str,
    body: MessageCreateRequest,
    session: Dependencies.Session,
    headers: Dependencies.Headers,
    config: Dependencies.Config,
):
    """Add a new message to a project."""
    user_email = _get_user_email(headers)
    _require_write_access(
        session, project_id, user_email, config.template_admin_emails
    )

    msg = Message(
        project_id=project_id,
        role=body.role,
        content=body.content,
        is_error=body.is_error,
    )
    session.add(msg)
    session.commit()
    session.refresh(msg)

    return MessageOut(
        id=msg.id,
        project_id=msg.project_id,
        role=msg.role,
        content=msg.content,
        context_hint=msg.context_hint,
        is_error=msg.is_error,
        is_cancelled=msg.is_cancelled,
        created_at=msg.created_at,
    )


@router.delete(
    "/projects/{project_id}/messages",
    operation_id="clearProjectMessages",
)
def clear_project_messages(
    project_id: str,
    session: Dependencies.Session,
    headers: Dependencies.Headers,
    config: Dependencies.Config,
):
    """Delete all messages for a project."""
    user_email = _get_user_email(headers)
    _require_write_access(
        session, project_id, user_email, config.template_admin_emails
    )

    messages = session.exec(
        select(Message).where(Message.project_id == project_id)
    ).all()

    for msg in messages:
        session.delete(msg)

    session.commit()

    return {"success": True, "deleted_count": len(messages)}


@router.post(
    "/projects/{project_id}/session/clear",
    operation_id="clearProjectSession",
)
async def clear_project_session(
    project_id: str,
    session: Dependencies.Session,
    headers: Dependencies.Headers,
    config: Dependencies.Config,
):
    """Clear project session: delete all messages, drop the SDK client,
    and clear `project.session_id` so the next turn starts a brand-new
    server-side conversation (no `options.resume`).

    Three pieces of state get reset, in this order:
      - All `messages` rows for the project (DB).
      - `project.session_id` set to NULL — without this, routes/agent.py
        keeps passing the old session_id into options.resume and the model
        keeps replying in the prior conversation despite us pulling the
        local client.
      - The pooled SDK client (its subprocess + in-process state).
    """
    import asyncio
    user_email = _get_user_email(headers)

    # Cancel any in-flight turn FIRST. Resetting the session / removing the
    # pooled client while a turn is mid-`receive_response` would disconnect the
    # client out from under it (use-after-disconnect) AND the turn's completion
    # would re-persist the session_id we're about to clear (the reset wouldn't
    # stick). Cancelling flips the stream terminal so remove_client's guard sees
    # no in-flight turn and the turn's own finally does the teardown cleanly.
    from ..services.active_stream import get_stream_manager
    mgr = get_stream_manager()
    live = mgr.get_project_stream(project_id)
    if live is not None:
        live.mark_cancelled()
        task = getattr(live, "task", None)
        if task is not None and not task.done():
            task.cancel()
        # Give the cancellation a moment to unwind the turn's teardown.
        for _ in range(20):
            if mgr.get_project_stream(project_id) is None:
                break
            await asyncio.sleep(0.05)

    # DB work on a worker thread — sync psycopg would otherwise block the loop.
    def _reset_db_state() -> int:
        project = _require_write_access(
            session, project_id, user_email, config.template_admin_emails
        )
        messages = session.exec(
            select(Message).where(Message.project_id == project_id)
        ).all()
        for msg in messages:
            session.delete(msg)
        # Forget the prior server-side session so the next turn is fresh.
        project.session_id = None
        session.add(project)
        session.commit()
        return len(messages)

    deleted_count = await asyncio.to_thread(_reset_db_state)

    # Remove client from pool (this clears the local SDK session).
    pool = get_client_pool()
    await pool.remove_client(project_id)

    return {"success": True, "deleted_count": deleted_count}
